import React from 'react'
import BasicForm from './BasicForm'
import Form from './Form'

function Main() {
  return (
    <div>
        {/* <BasicForm/> */}
        <Form/>
    </div>
  )
}

export default Main